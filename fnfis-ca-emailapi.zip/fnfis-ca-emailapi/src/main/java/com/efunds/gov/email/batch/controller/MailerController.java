package com.efunds.gov.email.batch.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.efunds.gov.email.batch.common.Commons;
import com.efunds.gov.email.batch.dao.MailerDAO;
import com.efunds.gov.email.batch.mailer.MailProcessor;


public class MailerController {
	
	private final Logger logger = Logger.getLogger(MailerController.class);

	private String dateOfRun = null;
	private Calendar calculatedDate;
	private MailProcessor emailProcessor = null;
	private MailerDAO emailDAO = null;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private String agency = System.getProperty("agency");

	//
	public void callEmailModule() {		
		
		emailDAO.demoAlertTableStatusOn();
		
		logger.info("MailerController.callEmailModule() -> Enter");
		
		if (StringUtils.isNotBlank(dateOfRun) || StringUtils.isNotEmpty(dateOfRun)) {
			setDate(dateOfRun);
		}

		try {
			List sendEmailList = null;
			Calendar currentTime = Calendar.getInstance();
			while(currentTime.before(Commons.END_TIME)) {				
				
				// 1. Reading list of emails from DB, the size of list is set in jdbcTemplate: maxRows=100
				sendEmailList = (List) emailDAO.getEmailList(dateFormat.format(calculatedDate.getTime()), agency);
				if(sendEmailList == null || sendEmailList.size() == 0) {
					break;
				}
				
				// 2. Sending Emails
				List resultList = emailProcessor.sendEmail(sendEmailList);				
				
				// 3. Updating Alert table, batchUpdate
				if(resultList != null && resultList.size() > 0){
					emailDAO.updateAlertTable(resultList);
				}
				
				currentTime = Calendar.getInstance();
				System.out.println("-------------------------------------------------------------------------------");
			}
		} catch (Exception ex) {
			System.setProperty("abnormalTermination", "yes");
			System.setProperty("abnormalException", ex.getMessage());
		}
		
		logger.info("MailerController.callEmailModule() -> Exit");
		
	}

	
	
	public MailerController() {
		calculatedDate = Calendar.getInstance();
	}
	
	public void setDateOfRun(String string) {
		dateOfRun = string;
	}
	public void setEmailDAO(MailerDAO emailDAO) {
		this.emailDAO = emailDAO;
	}
	public void setEmailProcessor(MailProcessor emailProcessor) {
		this.emailProcessor = emailProcessor;
	}
	private void setDate(String dateOfRun) {
		calculatedDate.set(getInt(dateOfRun.substring(6, 10)), getInt(dateOfRun
				.substring(0, 2)) - 1, getInt(dateOfRun.substring(3, 5)));		
	}
	private int getInt(String string) {
		return Integer.parseInt(string.trim());
	}

}
