package com.efunds.gov.email.batch.dao;


public class EmailDTO {

	private String pan = null;
	private String email = null;
	private String clientID = null;
	private String alertData = null;
	private String alertID = null;
	private String subject = null;
	private String caseNum = null;
	private String casePrefix = null;
	private String agency = null;
	private String authNum = null;
	private String availTS = null;
	private String pgmClass = null;
	private String cardStatus = null;
	private String servicesList = null;	
	private String authAmt = null;
	private String panPrefix = null;
	private String isFS = null;
	private String isCA = null;
	private String isWIC = null;
	private String isTA = null;
	private String isCC = null;
	
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getAlertData() {
		return alertData;
	}
	public void setAlertData(String alertData) {
		this.alertData = alertData;
	}
	public String getAlertID() {
		return alertID;
	}
	public void setAlertID(String alertID) {
		this.alertID = alertID;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getCaseNum() {
		return caseNum;
	}
	public void setCaseNum(String caseNum) {
		this.caseNum = caseNum;
	}
	public String getCasePrefix() {
		return casePrefix;
	}
	public void setCasePrefix(String casePrefix) {
		this.casePrefix = casePrefix;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getAuthNum() {
		return authNum;
	}
	public void setAuthNum(String authNum) {
		this.authNum = authNum;
	}
	public String getAuthTS() {
		return availTS;
	}
	public void setAvailTS(String availTS) {
		this.availTS = availTS;
	}
	public String getPgmClass() {
		return pgmClass;
	}
	public void setPgmClass(String pgmClass) {
		this.pgmClass = pgmClass;
	}
	public String getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	public String getServicesList() {
		return servicesList;
	}
	public void setServicesList(String servicesList) {
		this.servicesList = servicesList;
	}
	public String getAuthAmt() {
		return authAmt;
	}
	public void setAuthAmt(String authAmt) {
		this.authAmt = authAmt;
	}
	public String getPanPrefix() {
		return panPrefix;
	}
	public void setPanPrefix(String panPrefix) {
		this.panPrefix = panPrefix;
	}
	public String getIsFS() {
		return isFS;
	}
	public void setIsFS(String isFS) {
		this.isFS = isFS;
	}
	public String getIsCA() {
		return isCA;
	}
	public void setIsCA(String isCA) {
		this.isCA = isCA;
	}
	public String getIsWIC() {
		return isWIC;
	}
	public void setIsWIC(String isWIC) {
		this.isWIC = isWIC;
	}
	public String getIsTA() {
		return isTA;
	}
	public void setIsTA(String isTA) {
		this.isTA = isTA;
	}
	public String getIsCC() {
		return isCC;
	}
	public void setIsCC(String isCC) {
		this.isCC = isCC;
	}
	public String getAvailTS() {
		return availTS;
	}
	@Override
	public String toString() {
		return "SendEmailDTO [pan=" + pan + ", email=" + email + ", clientID=" + clientID + ", alertData=" + alertData
				+ ", alertID=" + alertID + ", subject=" + subject + ", caseNum=" + caseNum + ", casePrefix="
				+ casePrefix + ", agency=" + agency + ", authNum=" + authNum + ", availTS=" + availTS + ", pgmClass="
				+ pgmClass + ", cardStatus=" + cardStatus + ", servicesList=" + servicesList + ", authAmt=" + authAmt
				+ ", panPrefix=" + panPrefix + ", isFS=" + isFS + ", isCA=" + isCA + ", isWIC=" + isWIC + ", isTA="
				+ isTA + ", isCC=" + isCC + "]";
	}

	
	
	
	
	
}
