package com.efunds.gov.email.batch.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class EmailRowMapper implements RowMapper {

	public EmailRowMapper() {
		super();
	}

	public Object mapRow(ResultSet result, int arg1) throws SQLException {
		EmailDTO emailDTO = new EmailDTO();
		
		emailDTO.setAlertID(result.getString(1).trim());
		emailDTO.setAlertData(result.getString(2).trim());
		emailDTO.setPan(result.getString(3).trim());
		emailDTO.setEmail(result.getString(4).trim());
		emailDTO.setClientID(result.getString(5).trim());
		
		return emailDTO;
	}
}
