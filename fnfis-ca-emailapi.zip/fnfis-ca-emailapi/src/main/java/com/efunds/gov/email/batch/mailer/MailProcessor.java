package com.efunds.gov.email.batch.mailer;

import java.util.List;

public interface MailProcessor {
	public List sendEmail(List sendEmailList);
}
