package com.efunds.gov.email.batch.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

public class MailerDAOImpl implements MailerDAO {
	
	private final Logger logger = Logger.getLogger(MailerDAOImpl.class);  
	
	public static String queryForEmailList =	"SELECT ALERT.ALERT_ID, ALERT.ALERT_DATA, " +
			"ALERT.PAN, CLNT.EMAIL_ADDRESS, CLNT.CLIENT " +
			"FROM SSALRTV1 ALERT, " + 
			"SSCLNTV8 CLNT " + 
			"WHERE " + 
			"ALERT.ALERT_MODE = 'E' AND " + 
			"EXTEND(ALERT.LAST_MOD_TS, YEAR TO DAY) = ? AND " + 
			"ALERT.ALERT_STATUS <> 'D' AND " + 
			"ALERT.AGENCY = ? AND " + 
			"CLNT.CLIENT = ALERT.CLIENT " + 
			"FOR BROWSE ACCESS;";	

	public static String queryForUpdateAlertTable =	"UPDATE SSALRTV1 SET ALERT_STATUS = 'D', LAST_MOD_TS = CURRENT " +
				"WHERE ALERT_ID = ? AND CLIENT = ? FOR STABLE ACCESS;";
	
	
	public MailerDAOImpl() {}

	private JdbcTemplate jdbcTemplate = null;
	public void setJdbcTemplate(JdbcTemplate template) {
		jdbcTemplate = template;
	}

	
	@SuppressWarnings("unchecked")
	public List getEmailList(String timeStamp, String agency) {		
		logger.info("MailerDAOImpl.getEmailList -> Enter");
		
		Object timeStampObj = timeStamp;
		Object agencyObj = agency;
		final Object[] params = new Object[2];
		params[0] = timeStampObj; // timeStamp
		params[1] = agencyObj; //Agency
		
		
		List list = jdbcTemplate.query(queryForEmailList, params, new EmailRowMapper());
		
				
		if (list == null || list.size() == 0) {
			logger.error("Error: No Data found in AE Table for Email Alert services.");
		} else {
			logger.info("Total Data found in AE Table for Email Alert Services : " + list.size());
		}
		
		logger.info("MailerDAOImpl.getEmailList -> Exit");		
		return list;
	}
	
	
	
	@Override
	public void updateAlertTable(final List list) {
		logger.info("MailerDAOImpl.updateAlertTable -> Enter");
		
		if(list != null && list.size() > 0) {
			
			int[] rowsEffected = jdbcTemplate.batchUpdate(queryForUpdateAlertTable, 
															new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					EmailDTO email = (EmailDTO)list.get(i);
					ps.setString(1, email.getAlertID());
					ps.setString(2, email.getClientID());
				}
				
				@Override
				public int getBatchSize() {
					return list.size();
				}
			});
			
			if(rowsEffected.length != list.size()){				
				logger.info("Batch update Alert Table was not Successful");
			}			
		}else {
			logger.info("Batch update Alert Table, input list is empty");
		}
		
		logger.info("MailerDAOImpl.updateAlertTable -> Exit");
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// will be deleted
	@Override
	public void demoPopulateAlertTable() {
		
		int total = jdbcTemplate.update("DELETE FROM SSALRTV1;");
		System.out.println("Total #of Alert rows deleted: " + total);
		
		total = jdbcTemplate.update(queryInsertALRT);
		System.out.println("Total #of Alert rows added: " + total);
		
	}


	@Override
	public void demoPopulateClientTable() {
		
		int total = jdbcTemplate.update(queryInsertCLNT);
		System.out.println("Total #of Alert rows added: " + total);
		
	}


	@Override
	public void demoAlertTableStatusOn() {
		int total = jdbcTemplate.update(queryForUpdateAlertTableStatus);
		System.out.println("Total #of Alert rows status changed: " + total);
	}
	
	
	public static String queryForUpdateAlertTableStatus = "UPDATE SSALRTV1 SET ALERT_STATUS = 'A' FOR STABLE ACCESS;";
	
	public static String queryForAddAlertTable = "INSERT INTO SSALRTV1(ALERT_ID, PAN_PREFIX, PAN, CASE_PREFIX, AGENCY, CASE_NUM, CLIENT, ALERT_MODE, ALERT_STATUS, LAST_MOD_TS, ALERT_DATA) VALUES" +
			"(1, '72', '5081390140434172', '94', 'CAEBT', '106585694605', '000001206639', 'E', 'A', CURRENT, 'A005,2013-09-16:18:36:02.557800,4172'), " +
			"(2, '40', '5081390140335940', '28', 'CAEBT', '128541728302', '000011432991', 'E', 'A', CURRENT, 'A005,2013-09-16:23:56:38.411820,5940'), " +
			"(3, '91', '5081390118064191', '33', 'CAEBT', '138195233001', '000016155594', 'E', 'A', CURRENT, 'A005,2013-09-17:17:37:12.590403,4191'), " +
			"(4, '24', '5081390146794124', '52', 'CAEBT', '140466852701', '000016528092', 'E', 'A', CURRENT, 'A004,2013-09-18:09:35:41.000087,4124'), " +
			"(5, '65', '5081390155784065', '89', 'CAEBT', '114030789401', '000005369706', 'E', 'A', CURRENT, 'A005,2013-09-19:13:42:46.753530,4065'), " +
			"(6, '49', '5081390126645049', '68', 'CAEBT', '124902768302', '000010944868', 'E', 'A', CURRENT, 'A005,2013-09-19:13:51:43.699299,5049'), " +
			"(7, '44', '5081390153564444', '98', 'CAEBT', '122491698101', '000010003302', 'E', 'A', CURRENT, 'A005,2013-09-19:16:55:56.557697,4444'), " +
			"(8, '89', '5081390157247889', '93', 'CAEBT', '127356193703', '000011272724', 'E', 'A', CURRENT, 'A005,2013-09-21:04:05:54.051107,7889'), " +
			"(9, '96', '5081390112279696', '94', 'CAEBT', '137237194001', '000016018737', 'E', 'A', CURRENT, 'A005,2013-09-21:18:12:25.592524,9696'), " +
			"(10, '37', '5081390136783137', '64', 'CAEBT', '139568164301', '000016376530', 'E', 'A', CURRENT, 'A005,2013-09-22:04:53:09.418575,3137'), " +
			"(11, '07', '5081390110419807', '94', 'CAEBT', '115263294902', '000005526995', 'E', 'A', CURRENT, 'A005,2013-10-01:17:45:59.746205,9807'), " +
			"(12, '36', '5081390145466336', '31', 'CAEBT', '140184931802', '000016483017', 'E', 'A', CURRENT, 'A005,2013-10-01:18:09:58.171146,6336'), " +
			"(13, '73', '5081390155210673', '59', 'CAEBT', '142161959801', '000016774173', 'E', 'A', CURRENT, 'A005,2013-10-01:19:58:41.246728,0673'), " +
			"(14, '89', '5081390157516689', '15', 'CAEBT', '127090415901', '000011239002', 'E', 'A', CURRENT, 'A005,2013-10-01:21:04:06.155761,6689'), " +
			"(15, '14', '5081392000126914', '41', 'CAEBT', '141722741901', '000016718120', 'E', 'A', CURRENT, 'A004,2013-10-01:21:21:49.000045,6914'), " +
			"(16, '31', '5081390115300531', '44', 'CAEBT', '123294444102', '000010616080', 'E', 'A', CURRENT, 'A005,2013-10-02:01:47:43.997651,0531'), " +
			"(17, '17', '5081390151656317', '90', 'CAEBT', '128561890402', '000011435819', 'E', 'A', CURRENT, 'A005,2013-10-02:03:39:39.418540,6317'), " +
			"(18, '73', '5081390155210673', '59', 'CAEBT', '142161959801', '000016774173', 'E', 'A', CURRENT, 'A005,2013-10-02:03:44:14.288848,0673'), " +
			"(19, '34', '5081390155823434', '01', 'CAEBT', '108224701403', '000001359851', 'E', 'A', CURRENT, 'A005,2013-10-02:09:33:34.690922,3434'), " +
			"(20, '72', '5081390140434172', '94', 'CAEBT', '106585694605', '000001206638', 'E', 'A', CURRENT, 'A005,2013-09-16:18:36:02.557800,4172'), " +
			"(21, '40', '5081390140335940', '28', 'CAEBT', '128541728302', '000011432990', 'E', 'A', CURRENT, 'A005,2013-09-16:23:56:38.411820,5940'), " +
			"(22, '91', '5081390118064191', '33', 'CAEBT', '138195233001', '000016155593', 'E', 'A', CURRENT, 'A005,2013-09-17:17:37:12.590403,4191'), " +
			"(23, '24', '5081390146794124', '52', 'CAEBT', '140466852701', '000016528091', 'E', 'A', CURRENT, 'A004,2013-09-18:09:35:41.000087,4124'), " +
			"(24, '65', '5081390155784065', '89', 'CAEBT', '114030789401', '000005369705', 'E', 'A', CURRENT, 'A005,2013-09-19:13:42:46.753530,4065'), " +
			"(25, '49', '5081390126645049', '68', 'CAEBT', '124902768302', '000010944867', 'E', 'A', CURRENT, 'A005,2013-09-19:13:51:43.699299,5049'), " +
			"(26, '44', '5081390153564444', '98', 'CAEBT', '122491698101', '000010003301', 'E', 'A', CURRENT, 'A005,2013-09-19:16:55:56.557697,4444'), " +
			"(27, '89', '5081390157247889', '93', 'CAEBT', '127356193703', '000011272723', 'E', 'A', CURRENT, 'A005,2013-09-21:04:05:54.051107,7889'), " +
			"(28, '96', '5081390112279696', '94', 'CAEBT', '137237194001', '000016018736', 'E', 'A', CURRENT, 'A005,2013-09-21:18:12:25.592524,9696'), " +
			"(29, '37', '5081390136783137', '64', 'CAEBT', '139568164301', '000016376529', 'E', 'A', CURRENT, 'A005,2013-09-22:04:53:09.418575,3137'), " +
			"(50, '07', '5081390110419807', '94', 'CAEBT', '115263294902', '000005526994', 'E', 'A', CURRENT, 'A005,2013-10-01:17:45:59.746205,9807'), " +
			"(51, '36', '5081390145466336', '31', 'CAEBT', '140184931802', '000016483016', 'E', 'A', CURRENT, 'A005,2013-10-01:18:09:58.171146,6336'), " +
			"(52, '73', '5081390155210673', '59', 'CAEBT', '142161959801', '000016774172', 'E', 'A', CURRENT, 'A005,2013-10-01:19:58:41.246728,0673'), " +
			"(53, '89', '5081390157516689', '15', 'CAEBT', '127090415901', '000011239001', 'E', 'A', CURRENT, 'A005,2013-10-01:21:04:06.155761,6689'), " +
			"(54, '14', '5081392000126914', '41', 'CAEBT', '141722741901', '000016718119', 'E', 'A', CURRENT, 'A004,2013-10-01:21:21:49.000045,6914'), " +
			"(55, '31', '5081390115300531', '44', 'CAEBT', '123294444102', '000010616079', 'E', 'A', CURRENT, 'A005,2013-10-02:01:47:43.997651,0531'), " +
			"(56, '17', '5081390151656317', '90', 'CAEBT', '128561890402', '000011435818', 'E', 'A', CURRENT, 'A005,2013-10-02:03:39:39.418540,6317'), " +
			"(57, '73', '5081390155210673', '59', 'CAEBT', '142161959801', '000016774172', 'E', 'A', CURRENT, 'A005,2013-10-02:03:44:14.288848,0673'), " +
			"(58, '34', '5081390155823434', '01', 'CAEBT', '108224701403', '000001359850', 'E', 'A', CURRENT, 'A005,2013-10-02:09:33:34.690922,3434'), " +
			"(59, '33', '5081390140017233', '54', 'CAEBT', '127510454102', '000011292908', 'E', 'A', CURRENT, 'A005,2013-10-02:09:46:06.912648,7233'), " +
			"(60, '49', '5081390116600749', '32', 'CAEBT', '138117332202', '000016145359', 'E', 'A', CURRENT, 'A004,2013-10-02:10:30:18.000099,0749'), " +
			"(61, '14', '5081392000126914', '41', 'CAEBT', '141722741901', '000016718119', 'E', 'A', CURRENT, 'A004,2013-10-02:10:51:09.000093,6914'), " +
			"(62, '81', '5081392000295081', '45', 'CAEBT', '132933545701', '000015341314', 'E', 'A', CURRENT, 'A005,2013-10-02:10:59:25.540539,5081'), " +
			"(63, '73', '5081390147303073', '23', 'CAEBT', '131671623601', '000015127219', 'E', 'A', CURRENT, 'A005,2013-10-02:13:03:58.954896,3073'), " +
			"(64, '68', '5081390151259468', '56', 'CAEBT', '114527156103', '000005432421', 'E', 'A', CURRENT, 'A004,2013-10-02:13:49:42.000034,9468'), " +
			"(65, '21', '5081390154000521', '95', 'CAEBT', '133137995401', '000015374478', 'E', 'A', CURRENT, 'A005,2013-10-02:17:39:21.919850,0521'), " +
			"(66, '80', '5081390114142280', '88', 'CAEBT', '111914388801', '000005102429', 'E', 'A', CURRENT, 'A004,2013-10-02:21:45:07.000044,2280'), " +
			"(67, '59', '5081390142581459', '95', 'CAEBT', '140002695405', '000016451847', 'E', 'A', CURRENT, 'A005,2013-10-02:22:18:34.478110,1459'), " +
			"(68, '48', '5081390152485948', '47', 'CAEBT', '118169147803', '000005883314', 'E', 'A', CURRENT, 'A005,2013-10-03:03:50:28.520513,5948'), " +
			"(69, '73', '5081390155210673', '59', 'CAEBT', '142161959801', '000016774172', 'E', 'A', CURRENT, 'A005,2013-10-03:05:24:29.971580,0673');";
	
	
	
	public static String queryForAddClientTable = "INSERT INTO SSCLNTV8(CLIENT, EMAIL_ADDRESS) VALUES" +
			"('000001206639', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011432991', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016155594', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016528092', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005369706', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000010944868', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000010003302', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011272724', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016018737', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016376530', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005526995', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016483017', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016774371', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011239002', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016718120', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000010616080', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011435819', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016774173', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000001359851', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000001206638', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011432990', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016155593', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016528091', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005369705', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000010944867', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000010003301', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011272723', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016018736', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016376529', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005526994', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016483016', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016774172', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011239001', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016718119', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000010616079', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011435818', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016774177', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000001359850', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000011292908', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016145359', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016718111', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000015341314', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000015127219', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005432421', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000015374478', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005102429', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016451847', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000005883314', 'ulugbek.khusanov@fisglobal.com'), " +
			"('000016774175', 'ulugbek.khusanov@fisglobal.com');";
	
	
	
	
	
	
	

		public static String queryInsertCLNT = "INSERT INTO SSCLNTV8(CLIENT, EMAIL_ADDRESS) VALUES" +
										"('10001', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10002', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10003', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10004', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10005', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10006', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10007', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10008', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10009', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10010', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10011', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10012', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10013', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10014', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10015', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10016', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10017', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10018', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10019', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10020', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10021', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10022', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10023', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10024', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10025', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10026', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10027', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10028', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10029', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10030', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10031', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10032', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10033', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10034', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10035', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10036', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10037', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10038', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10039', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10040', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10041', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10042', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10043', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10044', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10045', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10046', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10047', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10048', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10049', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10050', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10051', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10052', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10053', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10054', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10055', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10056', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10057', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10058', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10059', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10060', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10061', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10062', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10063', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10064', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10065', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10066', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10067', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10068', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10069', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10070', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10071', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10072', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10073', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10074', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10075', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10076', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10077', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10078', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10079', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10080', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10081', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10082', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10083', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10084', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10085', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10086', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10087', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10088', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10089', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10090', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10091', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10092', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10093', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10094', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10095', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10096', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10097', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10098', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10099', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10100', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10101', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10102', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10103', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10104', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10105', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10106', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10107', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10108', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10109', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10110', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10111', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10112', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10113', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10114', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10115', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10116', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10117', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10118', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10119', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10120', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10121', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10122', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10123', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10124', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10125', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10126', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10127', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10128', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10129', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10130', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10131', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10132', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10133', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10134', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10135', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10136', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10137', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10138', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10139', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10140', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10141', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10142', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10143', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10144', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10145', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10146', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10147', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10148', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10149', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10150', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10151', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10152', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10153', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10154', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10155', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10156', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10157', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10158', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10159', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10160', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10161', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10162', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10163', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10164', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10165', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10166', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10167', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10168', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10169', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10170', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10171', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10172', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10173', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10174', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10175', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10176', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10177', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10178', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10179', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10180', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10181', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10182', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10183', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10184', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10185', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10186', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10187', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10188', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10189', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10190', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10191', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10192', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10193', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10194', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10195', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10196', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10197', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10198', 'ulugbek.khusanov@fisglobal.com'), " +
										"('10199', 'ulugbek.khusanov@fisglobal.com');";




		public static String queryInsertALRT = "INSERT INTO SSALRTV1(ALERT_ID, PAN_PREFIX, PAN, CASE_PREFIX, AGENCY, CASE_NUM, CLIENT, ALERT_MODE, ALERT_STATUS, LAST_MOD_TS, ALERT_DATA) VALUES" +
				"(100, '1', '5081390140434170', '94', 'CAEBT', '106585694605', '10001', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,4'), " +
				"(101, '2', '5081390140434170', '28', 'CAEBT', '106585694605', '10002', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,5'), " +
				"(102, '3', '5081390140434170', '94', 'CAEBT', '106585694605', '10003', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,6'), " +
				"(103, '4', '5081390140434170', '28', 'CAEBT', '106585694605', '10004', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,7'), " +
				"(104, '5', '5081390140434170', '94', 'CAEBT', '106585694605', '10005', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,8'), " +
				"(105, '6', '5081390140434170', '28', 'CAEBT', '106585694605', '10006', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,9'), " +
				"(106, '7', '5081390140434170', '94', 'CAEBT', '106585694605', '10007', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,10'), " +
				"(107, '8', '5081390140434170', '28', 'CAEBT', '106585694605', '10008', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,11'), " +
				"(108, '9', '5081390140434170', '94', 'CAEBT', '106585694605', '10009', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,12'), " +
				"(109, '10', '5081390140434170', '28', 'CAEBT', '106585694605', '10010', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,13'), " +
				"(110, '11', '5081390140434170', '94', 'CAEBT', '106585694605', '10011', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,14'), " +
				"(111, '12', '5081390140434170', '28', 'CAEBT', '106585694605', '10012', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,15'), " +
				"(112, '13', '5081390140434170', '94', 'CAEBT', '106585694605', '10013', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,16'), " +
				"(113, '14', '5081390140434170', '28', 'CAEBT', '106585694605', '10014', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,17'), " +
				"(114, '15', '5081390140434170', '94', 'CAEBT', '106585694605', '10015', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,18'), " +
				"(115, '16', '5081390140434170', '28', 'CAEBT', '106585694605', '10016', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,19'), " +
				"(116, '17', '5081390140434170', '94', 'CAEBT', '106585694605', '10017', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,20'), " +
				"(117, '18', '5081390140434170', '28', 'CAEBT', '106585694605', '10018', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,21'), " +
				"(118, '19', '5081390140434170', '94', 'CAEBT', '106585694605', '10019', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,22'), " +
				"(119, '20', '5081390140434170', '28', 'CAEBT', '106585694605', '10020', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,23'), " +
				"(120, '21', '5081390140434170', '94', 'CAEBT', '106585694605', '10021', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,24'), " +
				"(121, '22', '5081390140434170', '28', 'CAEBT', '106585694605', '10022', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,25'), " +
				"(122, '23', '5081390140434170', '94', 'CAEBT', '106585694605', '10023', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,26'), " +
				"(123, '24', '5081390140434170', '28', 'CAEBT', '106585694605', '10024', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,27'), " +
				"(124, '25', '5081390140434170', '94', 'CAEBT', '106585694605', '10025', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,28'), " +
				"(125, '26', '5081390140434170', '28', 'CAEBT', '106585694605', '10026', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,29'), " +
				"(126, '27', '5081390140434170', '94', 'CAEBT', '106585694605', '10027', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,30'), " +
				"(127, '28', '5081390140434170', '28', 'CAEBT', '106585694605', '10028', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,31'), " +
				"(128, '29', '5081390140434170', '94', 'CAEBT', '106585694605', '10029', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,32'), " +
				"(129, '30', '5081390140434170', '28', 'CAEBT', '106585694605', '10030', 'E', 'A', CURRENT, 'A010,CA,BENE_ACRONYM,5000,2017-09-16:18:36:02.557800,32'), " +
				"(130, '31', '5081390140434170', '94', 'CAEBT', '106585694605', '10031', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,500'), " +
				"(131, '32', '5081390140434170', '28', 'CAEBT', '106585694605', '10032', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,501'), " +
				"(132, '33', '5081390140434170', '94', 'CAEBT', '106585694605', '10033', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,502'), " +
				"(133, '34', '5081390140434170', '28', 'CAEBT', '106585694605', '10034', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,501'), " +
				"(134, '35', '5081390140434170', '94', 'CAEBT', '106585694605', '10035', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,502'), " +
				"(135, '36', '5081390140434170', '28', 'CAEBT', '106585694605', '10036', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,503'), " +
				"(136, '37', '5081390140434170', '94', 'CAEBT', '106585694605', '10037', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,502'), " +
				"(137, '38', '5081390140434170', '28', 'CAEBT', '106585694605', '10038', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,503'), " +
				"(138, '39', '5081390140434170', '94', 'CAEBT', '106585694605', '10039', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,504'), " +
				"(139, '40', '5081390140434170', '28', 'CAEBT', '106585694605', '10040', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,503'), " +
				"(140, '41', '5081390140434170', '94', 'CAEBT', '106585694605', '10041', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,501'), " +
				"(141, '42', '5081390140434170', '28', 'CAEBT', '106585694605', '10042', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,502'), " +
				"(142, '43', '5081390140434170', '94', 'CAEBT', '106585694605', '10043', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,503'), " +
				"(143, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10044', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,502'), " +
				"(144, '45', '5081390140434170', '94', 'CAEBT', '106585694605', '10045', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,503'), " +
				"(145, '46', '5081390140434170', '28', 'CAEBT', '106585694605', '10046', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,504'), " +
				"(146, '47', '5081390140434170', '94', 'CAEBT', '106585694605', '10047', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,503'), " +
				"(147, '48', '5081390140434170', '28', 'CAEBT', '106585694605', '10048', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,504'), " +
				"(148, '49', '5081390140434170', '94', 'CAEBT', '106585694605', '10049', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,505'), " +
				"(149, '50', '5081390140434170', '28', 'CAEBT', '106585694605', '10050', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,504'), " +
				"(150, '51', '5081390140434170', '94', 'CAEBT', '106585694605', '10051', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,502'), " +
				"(151, '52', '5081390140434170', '28', 'CAEBT', '106585694605', '10052', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,503'), " +
				"(152, '53', '5081390140434170', '94', 'CAEBT', '106585694605', '10053', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,504'), " +
				"(153, '54', '5081390140434170', '28', 'CAEBT', '106585694605', '10054', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,503'), " +
				"(154, '55', '5081390140434170', '94', 'CAEBT', '106585694605', '10055', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,504'), " +
				"(155, '56', '5081390140434170', '28', 'CAEBT', '106585694605', '10056', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,505'), " +
				"(156, '57', '5081390140434170', '94', 'CAEBT', '106585694605', '10057', 'E', 'A', CURRENT, 'A011,2000,1001,2017-09-16:18:36:02.557800,CA,504'), " +		
				"(157, '58', '5081390140434170', '28', 'CAEBT', '106585694605', '10058', 'E', 'A', CURRENT, 'A011,3000,1002,2017-09-16:18:36:02.557800,CA,505'), " +
				"(158, '59', '5081390140434170', '94', 'CAEBT', '106585694605', '10059', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,CA,506'), " +
				"(159, '60', '5081390140434170', '28', 'CAEBT', '106585694605', '10060', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,506'), " +
				"(160, '61', '5081390140434170', '94', 'CAEBT', '106585694605', '10061', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,507'), " +
				"(161, '62', '5081390140434170', '28', 'CAEBT', '106585694605', '10062', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,508'), " +
				"(162, '63', '5081390140434170', '94', 'CAEBT', '106585694605', '10063', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,509'), " +
				"(163, '64', '5081390140434170', '28', 'CAEBT', '106585694605', '10064', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,510'), " +
				"(164, '65', '5081390140434170', '94', 'CAEBT', '106585694605', '10065', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,511'), " +
				"(165, '66', '5081390140434170', '28', 'CAEBT', '106585694605', '10066', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,512'), " +
				"(166, '67', '5081390140434170', '94', 'CAEBT', '106585694605', '10067', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,513'), " +
				"(167, '68', '5081390140434170', '28', 'CAEBT', '106585694605', '10068', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,514'), " +
				"(168, '69', '5081390140434170', '94', 'CAEBT', '106585694605', '10069', 'E', 'A', CURRENT, 'A011,4000,1003,2017-09-16:18:36:02.557800,FS,515'), " +
				"(169, '70', '5081390140434170', '28', 'CAEBT', '106585694605', '10070', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000001'), " +
				"(170, '71', '5081390140434170', '94', 'CAEBT', '106585694605', '10071', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000002'), " +
				"(171, '72', '5081390140434170', '28', 'CAEBT', '106585694605', '10072', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000003'), " +
				"(172, '73', '5081390140434170', '94', 'CAEBT', '106585694605', '10073', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000004'), " +
				"(173, '74', '5081390140434170', '28', 'CAEBT', '106585694605', '10074', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000005'), " +
				"(174, '75', '5081390140434170', '94', 'CAEBT', '106585694605', '10075', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000006'), " +
				"(175, '76', '5081390140434170', '28', 'CAEBT', '106585694605', '10076', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000007'), " +
				"(176, '77', '5081390140434170', '94', 'CAEBT', '106585694605', '10077', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000008'), " +
				"(177, '78', '5081390140434170', '28', 'CAEBT', '106585694605', '10078', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000009'), " +
				"(178, '79', '5081390140434170', '94', 'CAEBT', '106585694605', '10079', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000010'), " +
				"(179, '80', '5081390140434170', '28', 'CAEBT', '106585694605', '10080', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000011'), " +
				"(180, '81', '5081390140434170', '94', 'CAEBT', '106585694605', '10081', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000012'), " +
				"(181, '82', '5081390140434170', '28', 'CAEBT', '106585694605', '10082', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000013'), " +
				"(182, '83', '5081390140434170', '94', 'CAEBT', '106585694605', '10083', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000014'), " +
				"(183, '84', '5081390140434170', '28', 'CAEBT', '106585694605', '10084', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000015'), " +
				"(184, '85', '5081390140434170', '94', 'CAEBT', '106585694605', '10085', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000016'), " +
				"(185, '86', '5081390140434170', '28', 'CAEBT', '106585694605', '10086', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000017'), " +
				"(186, '87', '5081390140434170', '94', 'CAEBT', '106585694605', '10087', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000018'), " +
				"(187, '88', '5081390140434170', '28', 'CAEBT', '106585694605', '10088', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000019'), " +
				"(188, '89', '5081390140434170', '94', 'CAEBT', '106585694605', '10089', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000020'), " +
				"(189, '90', '5081390140434170', '28', 'CAEBT', '106585694605', '10090', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000021'), " +
				"(190, '91', '5081390140434170', '94', 'CAEBT', '106585694605', '10091', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000022'), " +
				"(191, '92', '5081390140434170', '28', 'CAEBT', '106585694605', '10092', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000023'), " +
				"(192, '93', '5081390140434170', '94', 'CAEBT', '106585694605', '10093', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000024'), " +
				"(193, '94', '5081390140434170', '28', 'CAEBT', '106585694605', '10094', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000025'), " +
				"(194, '95', '5081390140434170', '94', 'CAEBT', '106585694605', '10095', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000026'), " +
				"(195, '96', '5081390140434170', '28', 'CAEBT', '106585694605', '10096', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000027'), " +
				"(196, '97', '5081390140434170', '94', 'CAEBT', '106585694605', '10097', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000028'), " +
				"(197, '98', '5081390140434170', '28', 'CAEBT', '106585694605', '10098', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000029'), " +
				"(198, '99', '5081390140434170', '94', 'CAEBT', '106585694605', '10099', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000030'), " +				
				"(199, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10100', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000031'), " +
				"(200, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10101', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000032'), " +
				"(201, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10102', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000033'), " +
				"(202, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10103', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000034'), " +
				"(203, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10104', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000035'), " +
				"(204, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10105', 'E', 'A', CURRENT, 'A012,5000,10001,11,2017-09-16:18:36:02.557800,4,10000036'), " +
				"(205, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10106', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000036'), " +
				"(206, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10107', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000037'), " +
				"(207, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10108', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000038'), " +			
				"(208, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10109', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000039'), " +
				"(209, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10110', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000040'), " +
				"(210, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10111', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000041'), " +
				"(211, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10112', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000042'), " +
				"(212, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10113', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000043'), " +
				"(213, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10114', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000044'), " +
				"(214, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10115', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000045'), " +
				"(215, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10116', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000046'), " +
				"(216, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10117', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000047'), " +
				"(217, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10118', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000048'), " +
				"(218, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10119', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000049'), " +
				"(219, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10120', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000050'), " +
				"(220, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10121', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000051'), " +
				"(221, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10122', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000052'), " +
				"(222, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10123', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000053'), " +
				"(223, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10124', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000054'), " +
				"(224, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10125', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000055'), " +
				"(225, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10126', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000056'), " +
				"(226, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10127', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000057'), " +
				"(227, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10128', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000058'), " +
				"(228, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10129', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000059'), " +
				"(229, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10130', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000060'), " +
				"(230, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10131', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000061'), " +
				"(231, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10132', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000062'), " +
				"(232, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10133', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000063'), " +
				"(233, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10134', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000064'), " +
				"(234, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10135', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000065'), " +
				"(235, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10136', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000066'), " +
				"(236, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10137', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000067'), " +
				"(237, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10138', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000068'), " +
				"(238, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10139', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000069'), " +
				"(239, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10140', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000070'), " +
				"(240, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10141', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000071'), " +
				"(241, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10142', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000072'), " +
				"(242, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10143', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000073'), " +
				"(243, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10144', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000074'), " +
				"(244, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10145', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000075'), " +
				"(245, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10146', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000076'), " +
				"(246, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10147', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000077'), " +
				"(247, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10148', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000078'), " +
				"(248, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10149', 'E', 'A', CURRENT, 'A013,5000,20001,31,2017-09-16:18:36:02.557800,3,10000079'), " +
				"(249, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10150', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000079'), " +
				"(250, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10151', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000080'), " +
				"(251, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10152', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000081'), " +
				"(252, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10153', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000082'), " +
				"(253, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10154', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000083'), " +
				"(254, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10155', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000084'), " +
				"(255, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10156', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000085'), " +
				"(256, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10157', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000086'), " +
				"(257, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10158', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000087'), " +
				"(258, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10159', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000088'), " +
				"(259, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10160', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000089'), " +
				"(260, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10161', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000090'), " +
				"(261, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10162', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000091'), " +
				"(262, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10163', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000092'), " +
				"(263, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10164', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000093'), " +
				"(264, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10165', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000094'), " +
				"(265, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10166', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000095'), " +
				"(266, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10167', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000096'), " +
				"(267, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10168', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000097'), " +
				"(268, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10169', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000098'), " +
				"(269, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10170', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000099'), " +				
				"(270, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10171', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000100'), " +
				"(271, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10172', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000101'), " +
				"(272, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10173', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000102'), " +
				"(273, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10174', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000103'), " +
				"(274, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10175', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000104'), " +
				"(275, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10176', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000105'), " +
				"(276, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10177', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000106'), " +
				"(277, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10178', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000107'), " +
				"(278, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10179', 'E', 'A', CURRENT, 'A014,7000,30001,51,2017-09-16:18:36:02.557800,2,10000108'), " +
				"(279, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10180', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3000'), " +
				"(280, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10181', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3001'), " +
				"(281, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10182', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3002'), " +
				"(282, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10183', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3003'), " +
				"(283, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10184', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3004'), " +
				"(284, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10185', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3005'), " +
				"(285, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10186', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3006'), " +
				"(286, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10187', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3007'), " +
				"(287, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10188', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3008'), " +
				"(288, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10189', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3009'), " +
				"(289, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10190', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3010'), " +
				"(290, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10191', 'E', 'A', CURRENT, 'A015,4,BEN,5000,2017-09-16:18:36:02.557800,356,3011'), " +
				"(291, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10192', 'E', 'A', CURRENT, 'A016,Notification data 001'), " +
				"(292, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10193', 'E', 'A', CURRENT, 'A016,Notification data 002'), " +
				"(293, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10194', 'E', 'A', CURRENT, 'A016,Notification data 003'), " +
				"(294, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10195', 'E', 'A', CURRENT, 'A016,Notification data 004'), " +
				"(295, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10196', 'E', 'A', CURRENT, 'A016,Notification data 005'), " +
				"(296, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10197', 'E', 'A', CURRENT, 'A016,Notification data 006'), " +
				"(297, '44', '5081390140434170', '94', 'CAEBT', '106585694605', '10198', 'E', 'A', CURRENT, 'A016,Notification data 007'), " +
				"(298, '44', '5081390140434170', '28', 'CAEBT', '106585694605', '10199', 'E', 'A', CURRENT, 'A016,Notification data 008');";
	
	
	
	
	
	
	
	
	
	
	

}
