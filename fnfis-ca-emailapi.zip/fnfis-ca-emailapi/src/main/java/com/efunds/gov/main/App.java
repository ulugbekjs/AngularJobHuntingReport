package com.efunds.gov.main;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.efunds.gov.email.ondemand.EmailApi;
import com.efunds.gov.email.ondemand.EmailTemplate;

public class App {
	
	public static void main( String[] args )
    {
		Map<String, String> model = new HashMap<String, String>();
		model.put("firstName", "Premkumar");
		model.put("lastName", "Gajjela");
		model.put("signature", "FIS");
		model.put("location", "WI");
		
		EmailApi myapp = new EmailApi();
		myapp.setFrom("ulugbek.khusanov@yahoo.com")
		.setTo("Premkumar.G@fisglobal.com")
		.setTemplate(EmailTemplate.TEMPLATE_01, model)
		.addAttachment(new File("D:/attachments/sample-attachment-02.pdf"))
		.send();
		
	
		// This is sample usage of "on-demand EmailAPI"
		// all the source code for "on-demand EmailAPI" is in [com.efunds.gov.email.ondemand] package.
//		EmailAPI myapi = new EmailAPI();
//		
//		Map<String, String> model = new HashMap<String, String>();
//		model.put("firstName", "John");
//		model.put("lastName", "Deer");
//		model.put("signature", "FIS");
//		model.put("location", "WI");
//		
//		myapi.from("ulugbek.khusanov@yahoo.com")
//		.to("ulugbek.khusanov@fisglobal.com")		
//		.setEmailTemplate(EmailAPI.EmailTemplates.TEMPLATE_01, model)
//		.addAttachment(new File("D:/sample-attachment-01.pdf"))
//		.send();
//		
		
		
		
		
		// This is sample run for Email batch send
		/*	
		// Launcher will provide the 3 parameters: agency, dateOfRun, timeInterval
		// agency: "CAEBT"
		// dateOfRun: "09/28/2017"
		// timeInterval: 2 (in hours)
    	String[] tempArgs = {"CAEBT", "10/10/2017", "2"};
    	
    	// Setting up the System properties
    	Commons.setSystemProperties(tempArgs);
    	
    	ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"email-application.xml"});
    	BeanFactory factory = (BeanFactory) appContext;
    	MailerController controller = (MailerController)factory.getBean("emailController"); 
    	
    	// Launching the email module
    	controller.callEmailModule();
    	*/
		

    }



}
