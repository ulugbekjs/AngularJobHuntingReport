package com.efunds.gov.email.batch.mailer;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.efunds.gov.email.batch.common.Commons;
import com.efunds.gov.email.batch.dao.EmailDTO;

public class MailContent {
	
	private final static Logger logger = Logger.getLogger(MailContent.class);  

	private static StringBuffer mailStrBuf = null;
	private static Properties properties = Commons.loadApplicationProperties("email.properties");
	private static final String blankStr = " ";
	private static final String dotStr = ".";
	SimpleDateFormat df = new SimpleDateFormat("MM/dd/yy");
	
	
	public static String getEmailContent() {
		return mailStrBuf.toString();
	}
	
	public static void manipulateEmailContent(EmailDTO dto) {
		logger.info("MailContent.manipulateEmailContent -> Enter");

		mailStrBuf = new StringBuffer("");
		String alertData = dto.getAlertData();
		String tempArray[] = StringUtils.split(alertData, ",");

		int caseInt = Integer.parseInt(tempArray[0].substring(2, 4));
		
		switch (caseInt) {
		case 2:
			setDebitAdjContent(dto);
			break;

		case 4:
			setAddrChngContent(dto);
			break;

		case 5:
			setPINChngContent(dto);
			break;

		case 6:
			setBeneAuthContent(dto);
			break;
		
		// Addition
		case 10:
			set_BENE_AVAIL_Content(dto);
			break;
		case 11:
			set_CLEARING_CA_DEBIT_ADJ_Content(dto);
			break;
		case 12:
			set_CLEARING_FS_DEBIT_ADJ_Content(dto);
			break;
		case 13:
			set_CLEARING_CA_CREDIT_ADJ_Content(dto);
			break;
		case 14:
			set_CLEARING_FS_CREDIT_ADJ_Content(dto);
			break;
		case 15:
			set_BENEFIT_AGED_REPORT_NOTIF_LOG_Content(dto);
			break;
		case 16:
			set_NOTE_ADD_Content(dto);
			break;

		}
		
		logger.info("MailContent.manipulateEmailContent -> Exit");

	}
	
	
	private static void setBeneAuthContent(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.benefit.auth"));
		String alertData = dto.getAlertData();

		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.a")).append(
				getPgmClass(dto.getPgmClass())).append(blankStr);
		mailStrBuf.append(properties.getProperty("message.bene.auth1")).append(
				getAmountString(dto.getAuthAmt())).append(blankStr);
		if (StringUtils.equalsIgnoreCase(dto.getCardStatus(), "A")) {
			mailStrBuf.append(properties.getProperty("message.bene.auth2"));
			mailStrBuf.append(
					StringUtils.substring(dto.getPan(),
							dto.getPan().length() - 4, dto.getPan().length()))
					.append(dotStr);
		} else if (!StringUtils.equalsIgnoreCase(dto.getCardStatus(), "A")) {
			mailStrBuf.append(properties
					.getProperty("message.bene.auth.nocard"));
		}
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.bene.auth3"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer2"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer3"));
		mailStrBuf.append("\n\n\n\n");

	}

	private static void setPINChngContent(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.pin.chng"));
		String alertData = dto.getAlertData();
		String tempArray[] = StringUtils.split(alertData, ",");

		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.on")).append(
				deFormatDate(tempArray[1], 2)).append(blankStr);
		if (tempArray[2] != null) {
			mailStrBuf.append(properties.getProperty("message.pin.chng.card"));
			mailStrBuf.append(tempArray[2]).append(dotStr);
		} else if (tempArray[2] == null) {
			mailStrBuf
					.append(properties.getProperty("message.pin.chng.nocard"));
		}
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer1"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer2"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer3"));
		mailStrBuf.append("\n\n\n\n");

	}

	private static void setAddrChngContent(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.addr.chng"));
		String alertData = dto.getAlertData();
		String tempArray[] = StringUtils.split(alertData, ",");

		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.on")).append(
				deFormatDate(tempArray[1], 2)).append(blankStr);
		if (tempArray[2] != null) {
			mailStrBuf.append(properties.getProperty("message.addr.chng.card"));
			mailStrBuf.append(tempArray[2]).append(dotStr);
		} else if (tempArray[2] == null) {
			mailStrBuf.append(properties
					.getProperty("message.addr.chng.nocard"));
		}
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer1"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer2"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.email.footer3"));
		mailStrBuf.append("\n\n\n\n");

	}

	private static void setDebitAdjContent(EmailDTO dto) {

		dto.setSubject(properties.getProperty("subject.debit.adj"));
		String alertData = dto.getAlertData();
		String tempArray[] = StringUtils.split(alertData, ",");

		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.card1"))
				.append(tempArray[1]).append(blankStr);
		mailStrBuf.append(properties.getProperty("message.dbt.adj.card2"))
				.append(getPgmClass(tempArray[2])).append(blankStr);
		mailStrBuf.append(properties.getProperty("message.dbt.adj.balance"));
		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.date"))
				.append(deFormatDate(tempArray[3], 4));
		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.comp.date"))
				.append(deFormatDate(tempArray[4], 4));
		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.amt"))
				.append(getAmountString(tempArray[5]));
		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.ref.num"))
				.append(tempArray[6]);
		mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.reason"))
				.append(
						properties.getProperty("message.dbt.adj.reason."
								+ tempArray[7].trim()));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.msg1"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.msg2"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.dbt.adj.msg3"));
		mailStrBuf.append("\n\n\n\n");

	}
	
	
	// Additional
	public static void set_BENE_AVAIL_Content(EmailDTO dto) {
	    dto.setSubject(properties.getProperty("subject.bene.avail"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.bene.avail"));
		mailStrBuf.append("\n\n");
	}

	public static void set_CLEARING_CA_DEBIT_ADJ_Content(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.debit.adj.ca"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.debit.adj.ca"));
		mailStrBuf.append("\n\n");
	}

	public static void set_CLEARING_FS_DEBIT_ADJ_Content(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.debit.adj.fs"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.debit.adj.fs"));
		mailStrBuf.append("\n\n");
	}

	public static void set_CLEARING_CA_CREDIT_ADJ_Content(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.credit.adj.ca"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.credit.adj.ca"));
		mailStrBuf.append("\n\n");
	}

	public static void set_CLEARING_FS_CREDIT_ADJ_Content(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.credit.adj.fs"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.credit.adj.fs"));
		mailStrBuf.append("\n\n");
	}

	public static void set_BENEFIT_AGED_REPORT_NOTIF_LOG_Content(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.bene.aged"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.bene.aged"));
		mailStrBuf.append("\n\n");
	}

	public static void set_NOTE_ADD_Content(EmailDTO dto) {
		dto.setSubject(properties.getProperty("subject.note.add"));
		String alertData = dto.getAlertData();
	    String tempArray[] = StringUtils.split(alertData, ",");

	    mailStrBuf.append("\n");
		mailStrBuf.append(properties.getProperty("message.hello"));
		mailStrBuf.append("\n\n");
		mailStrBuf.append(properties.getProperty("message.note.add"));
		mailStrBuf.append("\n\n");
	}
	
	
		
	
	
	
	
	
	
	private static String getPgmClass(String string) {
		if (StringUtils.equals(string, "FS")) {
			return "Food";
		} else if (StringUtils.equals(string, "CA")) {
			return "Cash";
		}
		return null;
	}

	private static String deFormatDate(String date, int i) {

		if (i == 4) {
			return StringUtils.substring(date, 5, 7) + "-"
					+ StringUtils.substring(date, 8, 10) + "-"
					+ StringUtils.substring(date, 0, 4);
		} else if (i == 2) {
			return StringUtils.substring(date, 5, 7) + "-"
					+ StringUtils.substring(date, 8, 10) + "-"
					+ StringUtils.substring(date, 2, 4);
		}
		return null;

	}

	private static String getAmountString(String string) {

		BigDecimal amt = new BigDecimal(StringUtils.substring(string, 0, string
				.length() - 2));
		return amt.toString()
				+ "."
				+ StringUtils.substring(string, string.length() - 2, string
						.length());
	}
	
	
	
}
