package com.efunds.gov.email.batch.mailer;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;


public class Mailer {
	private JavaMailSenderImpl sender = null;
	private String from = null;
	private String[] to = null;
	
	private final Logger logger = Logger.getLogger(Mailer.class);  
	
	public Mailer() {
		super();
		sender = new JavaMailSenderImpl();
	}

	public void setHost(String host) {
		sender.setHost(host);
	}

	public void setTo(String sendTo) {
		to = sendTo.split(",");
	}

	public void setFrom(String string) {
		from = string;
	}
	
	public boolean sendEmail(String subject, String msg, String to, String from){
		logger.info("Mailer.sendEmail -> Enter");
		
		boolean output = true;
		try {
			MimeMessage mime = sender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mime);

			StringBuffer buf = new StringBuffer(msg);
			helper.setFrom(from);
			helper.setSubject(subject);
			helper.setText(buf.toString());
			helper.addTo(to);
			sender.send(mime);
		} catch(Exception e) {
			output = false;
			logger.error("Error: sending email failure to"+to);
			logger.error("Exception: " + e.getMessage());
		}
		
		logger.info("Mailer.sendEmail -> Exit");
		
		return output;
	}
}
