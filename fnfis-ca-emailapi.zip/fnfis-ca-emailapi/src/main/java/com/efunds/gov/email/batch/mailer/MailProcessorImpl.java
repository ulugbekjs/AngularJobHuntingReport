package com.efunds.gov.email.batch.mailer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.efunds.gov.email.batch.common.Commons;
import com.efunds.gov.email.batch.dao.EmailDTO;
import com.efunds.gov.email.batch.dao.MailerDAO;


public class MailProcessorImpl implements MailProcessor {
	
	private final Logger logger = Logger.getLogger(MailProcessorImpl.class);  
	
	private Mailer mailer = null;
	Properties properties = null;
	private MailerDAO emailDAO = null;
	private String agency = null;
	
	public MailProcessorImpl() {}
	
	public void setMailer(Mailer mailer) {
		this.mailer = mailer;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public void setEmailDAO(MailerDAO emailDAO) {
		this.emailDAO = emailDAO;
	}
	
	//
	public List sendEmail(List inputList) {
		logger.info("MailProcessorImpl.sendEmail() -> Enter");
		
		properties = Commons.loadApplicationProperties("email.properties");
		
		List outputList = new ArrayList<EmailDTO>();
		if (inputList != null && inputList.size() > 0) {
			EmailDTO dto = null;
			ListIterator itr = (ListIterator) inputList.listIterator();
			while (itr.hasNext()) {
				dto = (EmailDTO) itr.next();
				MailContent.manipulateEmailContent(dto);
				
				System.out.println("\n\n\n *****" + dto.getSubject() + ", " + MailContent.getEmailContent() + ", " +
									dto.getEmail() + ", " + properties.getProperty("from.addr") +"\n\n\n");
				
				
//				if(mailer.sendEmail(dto.getSubject(), MailContent.getEmailContent(),
//									dto.getEmail(), properties.getProperty("from.addr"))){
					outputList.add(dto);
//				}
				

			}			
		}

		logger.info("MailProcessorImpl.sendEmail() -> Exit");
		return outputList;
	}
}
