package com.efunds.gov.email.ondemand;

/*
 * Simple Email API to send emails with attachments via FIS SMTP relay.
 * 
 * @author E5399462
 * 
 * */


import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;


public class EmailApi {
	
	private JavaMailSenderImpl sender;
	private Mail mail;
	
	private final Logger logger = Logger.getLogger(EmailApi.class);	
	public EmailApi(){
		setHost();
		mail = new Mail();
	}
		
	public EmailApi setFrom(String mailFrom) {
		mail.setMailFrom(mailFrom);
		return this;
	}
	
	public EmailApi setTo(String mailTo) {
		mail.setMailTo(mailTo);
		return this;
	}
	
	public EmailApi addAttachment(File file){
		List <File> attachments;
		if(mail.getAttachments() == null){
			attachments = new ArrayList<File>();
		}else {
			attachments = mail.getAttachments();
		}
		attachments.add(file);
		mail.setAttachments(attachments);		
		return this;
	}
	
	public EmailApi setTemplate(EmailTemplate template, Map<String, String> model) {
		mail.setMailSubject(template.getEmailSubject());
		mail.setMailContent(getContentFromTemplate(template.getTemplateUrl(), model));
		return this;
	}
	
	public void send() {
		logger.info("Enter -> EmailApi.send()");
		try {
			MimeMessage mime = sender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mime, true);
			helper.setFrom(mail.getMailFrom());
			helper.setTo(mail.getMailTo());
			helper.setSubject(mail.getMailSubject());
			helper.setText(mail.getMailContent(), true);			
			
			if(mail.getAttachments() != null && mail.getAttachments().size() > 0){
				for(File attachment: mail.getAttachments()) {
					helper.addAttachment(attachment.getName(), attachment);
				}
			}
			
			logger.info(mail.getMailContent());
			sender.send(helper.getMimeMessage());
			
		} catch (MessagingException e) {
            logger.info("Error: " + e.getMessage());            
        }
		logger.info("Exit -> EmailApi.send()");
	}
	
	/*
	 * 
	 * This setup will be changed according to SMTP host
	 * 
	 * */
	private void setHost() {
		sender = new JavaMailSenderImpl();
		sender.setHost("smtp.gmail.com");
		sender.setPort(587);
		sender.setUsername("some@gmail.com");
		sender.setPassword("some-password");
		Properties props = new Properties();
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.starttls.enable", "true");
		props.setProperty("mail.debug", "true");		
		sender.setJavaMailProperties(props);		
	}
	/*
	 * takes templeteUrl and model to generate HTML page
	 * @param templateUrl, model
	 * 
	 * @return HTML page
	 * 
	 * */
	private String getContentFromTemplate(String templateUrl, Map<String, String> model) {
    	logger.info("Enter -> getContentFromTemplate()");
		
		StringBuffer content = new StringBuffer();
		try {
			FreeMarkerConfigurationFactoryBean fmConfigFactoryBean = new FreeMarkerConfigurationFactoryBean();
	        fmConfigFactoryBean.setTemplateLoaderPath("/templates/");
	        Configuration freeMarker = fmConfigFactoryBean.createConfiguration();
	        
            content.append(FreeMarkerTemplateUtils
            		.processTemplateIntoString(freeMarker.getTemplate(templateUrl), model));
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("Error: " + e.getMessage());
        }
        logger.info("Exit -> getContentFromTemplate()");
        return content.toString();
    }
	
	
}
