package com.efunds.gov.email.batch.common;

import java.io.InputStream;
import java.util.Calendar;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

public class Commons {

	public static Calendar END_TIME = null;
	
	public static void setSystemProperties(String args[]) {
		if(args.length < 3) {
			System.out.println("Not all arguments are provided. :( ");
		} else {
			System.setProperty("agency", args[0]);			// "CAEBT"
	    	System.setProperty("dateOfRun", args[1]);		// "09/28/2017"
	    	System.setProperty("runInterval", args[2]);		// "2", means it will be repeated every 2 hrs
	    	System.setProperty("schema", StringUtils.substring(args[0], 0, 2));		// "CA"
	    	
	    	int runInterval = Integer.parseInt(System.getProperty("runInterval")); 
	    	END_TIME = Calendar.getInstance();
	    	END_TIME.set(Calendar.HOUR_OF_DAY, END_TIME.get(Calendar.HOUR_OF_DAY)+runInterval);
	    	END_TIME.set(Calendar.MINUTE, END_TIME.get(Calendar.MINUTE)-5);
	    	
	    	setUrlPassword();
		}		
	}	
	
	private static void setUrlPassword() {

		Properties prop = loadApplicationProperties("jdbc.ae.properties");
		try {
			String encryptedValue = null;
			String masterKey = prop.getProperty("ae.masterkey");

			encryptedValue = getEncryptedValue(masterKey, prop.getProperty("ae.jdbc.encryptKey"), 
					prop.getProperty("ae.jdbc."+System.getProperty("schema")+".url"));
			
			System.setProperty("system.ae.url", encryptedValue);

			encryptedValue = getEncryptedValue(masterKey, prop.getProperty("ae.jdbc.encryptKey"), 
					prop.getProperty("ae.jdbc."+System.getProperty("schema")+".password"));
			
			System.setProperty("system.ae.password", encryptedValue);

		} catch (Exception e) {
			System.err.println("Exception when decrypting URL, Password");
			e.printStackTrace();
		}
	}
	
	public static Properties loadApplicationProperties(String propFileName) {
		Properties properties = new Properties();
		try {
			InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFileName);
			properties.load(inputStream);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return properties;
	}
	
	private static String getEncryptedValue(String masterKey, String encryptKey, String encryptString)
			throws Exception {
		String clearKey = DecryptPasswordTripleDES.decrypt(masterKey, encryptKey);
		return DecryptPasswordTripleDES.decrypt(clearKey, encryptString);
	}
}
